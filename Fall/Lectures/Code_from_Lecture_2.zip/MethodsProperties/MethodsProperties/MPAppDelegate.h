//
//  MPAppDelegate.h
//  MethodsProperties
//
//  Created by Tim Novikoff on 9/16/14.
//  Copyright (c) 2014 Tim Novikoff. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MPAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
